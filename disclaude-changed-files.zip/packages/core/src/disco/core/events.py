"""The Event type hierarchy — event-state-contract.md §2.

Events are the atomic unit of all conversation and agent state. The log of
events is append-only and the single source of truth (BoD Principle 3); State
(state.py) and the LLM View (view.py) are *pure functions* of the ordered log.

Field names, types, and method signatures here are **normative** (the contract
marks them [CONTRACT]); other subsystems deserialize and compare these shapes
without further coordination. Method *bodies* are implementation.
"""

from __future__ import annotations

import re
import uuid
from contextvars import ContextVar
from datetime import UTC, datetime
from enum import Enum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

from .dod import DoDPredicate

# Bump on a *breaking* change to any event shape. Adding an optional field with
# a default is backward-compatible and does NOT require a bump (§4 rule 2).
SCHEMA_VERSION = 1


class EventSource(str, Enum):
    """Who/what produced an event. Security and UI both depend on this (§1.6)."""

    USER = "user"
    AGENT = "agent"
    ENVIRONMENT = "environment"  # tool results, injected feedback, hooks
    SYSTEM = "system"  # lifecycle/status, condensation, errors


class EventKind(str, Enum):
    """Discriminator for the Event union. Serialized by value (§4 rule 4)."""

    MESSAGE = "message"
    ACTION = "action"
    OBSERVATION = "observation"
    AGENT_ERROR = "agent_error"
    CONDENSATION = "condensation"
    STATUS = "status"
    ERROR = "error"  # conversation-level error (distinct from agent_error)
    PLAN = "plan"  # a proposed, structured plan awaiting approval (Build plan-mode)
    REPORT = "report"  # a finished Deep Research multi-section grounded report
    ALTERNATIVES = "alternatives"  # 2–3 user-choosable options after repeated tool failure
    KNOWLEDGE = "knowledge"  # a scoped best-practice snippet (Cluster 7)
    DATASOURCE = "datasource"  # durable API/schema docs, condensation-immune (Cluster 7)
    DELIVERABLE = "deliverable"  # the agent's finished-artifact handoff signal
    SCHEDULE = "schedule"  # a schedule was created or deleted (RP-08)
    SCHEDULE_RUN = "schedule_run"  # a scheduled run fired (RP-08)
    CLARIFY = "clarify"  # pre-plan typed clarification questions (RP-13)
    CONTEXT_RESOLVED = "context_resolved"  # CXT-3: agent's DEFERRED snip mark (resolved range)
    CONTEXT_SUMMARY = "context_summary"  # CXT-3: durable summary written for a resolved range


def _new_id() -> str:
    return f"evt_{uuid.uuid4().hex}"


def _now() -> datetime:
    return datetime.now(UTC)


class BaseEvent(BaseModel):
    """Common envelope for every event. Subtypes add a typed payload.

    [CONTRACT] These fields exist on every event and never change meaning.

    `frozen=True` makes events immutable at the type level (invariant #1):
    accidental mutation becomes a runtime error, not a silent bug. The only
    field "filled in later" is `seq`, set by the store via `model_copy` (a new
    instance), never by in-place mutation.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    id: str = Field(default_factory=_new_id)
    # The `kind` discriminator is declared on each concrete subclass as a
    # `Literal[EventKind.X]` (the idiomatic Pydantic discriminated-union shape;
    # see `Event` below with `Field(discriminator="kind")`). Every concrete event
    # therefore carries `kind` — BaseEvent is the never-instantiated envelope.
    source: EventSource
    timestamp: datetime = Field(default_factory=_now)  # VOLATILE (§6.3)
    schema_version: int = Field(default=SCHEMA_VERSION)

    # Assigned by the EventStore at append time. None before persistence.
    # [CONTRACT] Monotonic, gap-free, per-conversation. Do NOT set manually.
    seq: int | None = Field(default=None)

    # Free-form, non-semantic metadata (tracing ids, UI hints). VOLATILE.
    # Never load-bearing for reconstruction or equality.
    meta: dict[str, Any] = Field(default_factory=dict)


class LLMConvertible:
    """Marker mixin. Events that subclass this can be rendered into an LLM
    message via `to_llm_message()`. The View (§5) only ever materializes
    LLMConvertible events. [CONTRACT]

    Deliberately a plain class with no fields so it composes with the frozen
    Pydantic BaseEvent without disturbing the model.
    """

    def to_llm_message(self) -> LLMMessage:
        raise NotImplementedError


# ---- payload value objects --------------------------------------------------


class LLMMessage(BaseModel):
    """Provider-neutral message shape. The LLM router (separate subsystem) maps
    this to/from provider formats. [CONTRACT at the router boundary.]"""

    model_config = ConfigDict(frozen=True)
    role: Literal["system", "user", "assistant", "tool"]
    content: str
    # Optional structured content (tool calls/results) carried opaquely; the
    # router owns provider-specific shaping.
    tool_calls: list[dict[str, Any]] | None = None
    tool_call_id: str | None = None  # VOLATILE
    images: list[str] | None = None  # data-URL base64 (data:image/png;base64,...)


class ToolCall(BaseModel):
    """A request to execute one tool. Produced by the agent, consumed by the
    tool subsystem (separate contract)."""

    model_config = ConfigDict(frozen=True)
    tool_name: str
    arguments: dict[str, Any]
    call_id: str = Field(default_factory=lambda: f"call_{uuid.uuid4().hex}")  # VOLATILE


class ToolResult(BaseModel):
    """The outcome of executing a ToolCall. Produced by the tool subsystem."""

    model_config = ConfigDict(frozen=True)
    call_id: str  # VOLATILE (correlates to ToolCall)
    tool_name: str
    success: bool
    content: str  # human/LLM-readable result text
    structured: dict[str, Any] | None = None  # optional machine payload
    error: str | None = None  # populated iff success is False


class PlanStep(BaseModel):
    """One capstone in a proposed plan. The agent emits a list of these via the
    `submit_plan` tool; the UI tracks each one's progress during the build."""

    model_config = ConfigDict(frozen=True)
    title: str  # short, plain-language capstone ("Scaffold the page + styles")
    detail: str | None = None  # optional elaboration
    # C18 / C1c — the step's optional machine-checkable done_condition, PERSISTED on the
    # event so it survives resume (the in-memory `_plan_step_predicates` map is lost on a
    # restart between submit_plan and approval; reading the predicate back off the durable
    # PlanEvent is what lets the C1c DoD gate re-arm after a crash).
    done_condition: DoDPredicate | None = None


class ReportSection(BaseModel):
    """One section of a Deep Research report — a section of the long-form output
    grounded in a specific subset of the per-run corpus. `cited_passage_ids` are
    the stable passage ids the citation UI resolves to source cards (mirror of
    the per-block citations in the existing GroundedAnswer shape). `confidence`
    + `disputed_notes` carry the honesty-at-scale signal: when sources agree
    cleanly the section is "high"; when they disagree the conflict is named."""

    model_config = ConfigDict(frozen=True)
    id: str  # stable identifier ("s0", "s1", ... — for ToC anchoring)
    title: str  # section heading the report renders verbatim
    markdown: str  # the section body — markdown with inline [[passage_id]] citations
    cited_passage_ids: list[str] = Field(default_factory=list)
    confidence: Literal["high", "mixed", "low"] = "high"
    # Plain-language notes naming any conflicts between sources for this section.
    # When sources contradict on a claim, the model writes a short note here so
    # the reader sees the disagreement, not a falsely-confident synthesis.
    disputed_notes: list[str] = Field(default_factory=list)
    unsupported_count: int = 0  # claims that failed NLI verification for this section


class SecurityRisk(str, Enum):
    """Mirrors §17 / the security contract. UNKNOWN is non-comparable."""

    UNKNOWN = "UNKNOWN"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class ConversationStatus(str, Enum):
    """The loop's explicit execution state machine (BoD §12.1)."""

    IDLE = "IDLE"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    STUCK = "STUCK"
    WAITING_FOR_CONFIRMATION = "WAITING_FOR_CONFIRMATION"
    # The agent proposed a plan and the loop is halted until the human approves
    # it (Build plan-mode). Mirrors WAITING_FOR_CONFIRMATION but gates the whole
    # plan up front, not one risky action.
    AWAITING_PLAN_APPROVAL = "AWAITING_PLAN_APPROVAL"
    # The run is halted for the user to decide. Reached two ways: (1) the agent
    # itself calls `ask_user` with options; (2) the harness circuit breaker fires
    # after `_circuit_breaker_threshold` consecutive failures and hands off rather
    # than grinding. The user clicks an option (when present) or steers via
    # send_message. (There is no `propose_alternatives` tool — the model uses
    # `ask_user`; the breaker is harness-driven.)
    AWAITING_USER_DECISION = "AWAITING_USER_DECISION"
    # The agent called `ask_user` with a FREE-FORM question (no options) and the
    # loop is halted until the user TYPES an answer. The two-way Ask-gate: unlike
    # AWAITING_USER_DECISION (pick a card), this is an open question the user
    # answers in prose. The user's reply (send_message / steer) IS the resume
    # signal — same re-kick semantics as AWAITING_USER_DECISION, just a different
    # surface (AskPanel, not the alternatives cards).
    AWAITING_USER_QUESTION = "AWAITING_USER_QUESTION"
    FINISHED = "FINISHED"
    ERROR = "ERROR"


# ---- concrete event types ---------------------------------------------------


class MessageEvent(BaseEvent, LLMConvertible):
    """A message from user, agent, or environment."""

    kind: Literal[EventKind.MESSAGE] = EventKind.MESSAGE
    message: LLMMessage

    def to_llm_message(self) -> LLMMessage:
        return self.message


class ActionEvent(BaseEvent, LLMConvertible):
    """The agent chose to take one tool action. One action per event
    (Principle 6). Carries the agent's reasoning and self-assessed risk."""

    kind: Literal[EventKind.ACTION] = EventKind.ACTION
    source: EventSource = EventSource.AGENT
    thought: str  # the agent's reasoning for this action
    tool_call: ToolCall
    # Agent's self-assessed risk; the independent analyzer may override
    # downstream (security contract). Part of the event for audit.
    self_assessed_risk: SecurityRisk = SecurityRisk.UNKNOWN
    # VOLATILE: correlates to the model completion that produced this action.
    llm_response_id: str | None = None

    def to_llm_message(self) -> LLMMessage:
        return LLMMessage(
            role="assistant",
            content=self.thought,
            tool_calls=[
                {
                    "id": self.tool_call.call_id,
                    "name": self.tool_call.tool_name,
                    "arguments": _snip_args(self.tool_call.arguments),
                }
            ],
        )


# A-S2 (the Snip shaper): the per-observation char cap applied at RENDER time
# (to_llm_message), NOT at storage. The full content stays in the event payload
# (and on disk for spilled artifacts) — only the LLM-facing message is trimmed.
# Reversible: the model re-runs the tool or file_reads the artifact for the rest.
_OBS_SNIP_CHARS = 8_000
_OBS_SNIP_HEAD = 5_000
_OBS_SNIP_TAIL = 2_000

# CW-6 — per-build override for the observation snip cap. to_llm_message() is a pure
# projection method with no tier/window access, but the snip MUST be raised for the
# assist-OFF (capable) tier in tandem with the read budget — otherwise a large
# file_read observation is snipped to a corrupted head/tail and the model re-reads
# forever. ViewBuilder.build sets this from the derived ContextCaps for the duration
# of a build; default None → the byte-identical assist-ON 8k snip. Task-local
# (ContextVar) so concurrent conversations of different tiers never cross-contaminate.
obs_snip_override: ContextVar[int | None] = ContextVar(
    "disco_obs_snip_override", default=None
)


def snip_content(content: str, *, max_chars: int, head: int, tail: int) -> str:
    """Trim an over-long string to head + tail with a recoverable marker. Pure +
    deterministic (same input → same output) so it preserves View.of purity."""
    if len(content) <= max_chars:
        return content
    dropped = len(content) - head - tail
    return (
        f"{content[:head]}\n"
        f"… [snipped {dropped:,} chars — re-run the tool or use file_read for the full output] …\n"
        f"{content[-tail:]}"
    )


# H2: elide large ARGUMENT values (e.g. a file_write's full body) at RENDER time.
# A written file's content doesn't belong in the action history every turn — it's on
# disk + readable. Re-sending a 59 KB body each action is the dominant cost bloat.
# Pure + deterministic (preserves View.of purity); reversible (the marker tells the
# model the file exists + to file_read it).
_ARG_SNIP_CHARS = 1_500

# CW-3 — the leading marker of the always-fresh workspace snapshot block (the pinned
# CURRENT WORKSPACE message rendered by view_render.workspace_snapshot_message). Shared
# here (the lowest common module both the loop renderer and the provider import) so the
# provider can locate the block to place an Anthropic cache breakpoint after it, and so
# recovery/pointer prose can reference it by a LOCATION-INDEPENDENT name ("the CURRENT
# WORKSPACE block in this prompt" — never "below"/"above": the block moved to the
# cacheable prefix, so directional words are wrong).
WORKSPACE_SNAPSHOT_SENTINEL = "# CURRENT WORKSPACE"


# K1 — the elision-marker family. `_snip_args` renders an over-long arg as a
# placeholder in the action history. A weak model can COPY that placeholder back
# into a REAL tool argument (e.g. a file_write body), which — if executed — would
# write the ~72-byte placeholder over real content (DATA LOSS) and re-feed the
# marker into the next file_read (an 88× read loop, reproduced live). The marker
# is reworded to point at the live CURRENT WORKSPACE snapshot (never "use
# file_read", which invites the read loop). The DETECTOR below matches the marker
# STRUCTURE — `<N chars … {elided|full content} …>` — not the exact wording, so
# the marker can be reworded freely without the execution guard going blind.
_ELISION_MARKER_RE = re.compile(r"<\s*\d[\d,]*\s*chars\b[^>]*?\b(?:elided|full content)\b[^>]*>")
# CW P1-a — capture the char count from an existing marker so the assist-OFF retarget
# pass can re-render it (pinned vs non-pinned) without re-deriving the original length.
_ELISION_COUNT_RE = re.compile(r"<\s*(\d[\d,]*)\s*chars\b")

# BW-02 (trace conv_20fa8482) — a model can PARAPHRASE the neutral marker, dropping the
# leading "<N chars …>" anchor while copying the marker's stable TAIL prose verbatim into
# a real tool argument (observed: "<content elided — re-issue the call or file_read the
# path for the full content; do not copy this placeholder into a tool argument>"). With
# no digit anchor, `_ELISION_MARKER_RE` misses it, so K1 passed it and a 132-byte
# placeholder overwrote a real file (DATA LOSS → build corruption → degenerate tool-less
# resumes). This SECOND detector is for the REJECTION path ONLY: it matches a bounded
# angle-bracket placeholder `<…>` (no greedy cross-`>`) that carries BOTH the marker's
# signature TAIL phrase AND an elision keyword — requiring BOTH so it does NOT
# false-positive on ordinary file content that merely says "elided" in prose. It is NOT
# used by the RETARGET pass (which still needs the char count from `_ELISION_COUNT_RE` to
# reconstruct the neutral marker, and a paraphrase carries no count to reconstruct).
_ELISION_PARAPHRASE_RE = re.compile(
    r"<"
    r"(?=[^>]*\b(?:elided|full content|placeholder)\b)"
    r"[^>]*"
    # signature TAIL phrases — kept in lockstep with `_arg_snip_marker_neutral`. Legacy
    # phrases stay (back-compat for any in-flight marker); the de-temptified wording adds
    # "do not copy or re-send" + "already applied to the workspace".
    r"(?:re-issue the call or file_read the path|do not copy this placeholder"
    r"|do not copy or re-send|already applied to the workspace)"
    r"[^>]*>"
)


# CW P1-c — the DEFAULT / assist-ON elided-arg marker: the pre-CW-3 directional bytes.
# For assist-ON the CURRENT WORKSPACE block stays in the TAIL (after the history), so
# "below" is CORRECT, and this is the byte-identical pre-CW-3 wording. `_snip_args`
# (the View.of render, which has no tier context) always emits THIS; assist-OFF then
# rewrites it via `retarget_elided_arg_markers` (below) to the NEUTRAL marker because
# that tier moved the block to the cacheable PREFIX, where a directional word is wrong.
def _arg_snip_marker_below(n: int) -> str:
    return (
        f"<{n:,} chars — full content is in the CURRENT WORKSPACE block "
        "below; do not copy this placeholder into a tool argument>"
    )


# CW P1-a (round-2) — the assist-OFF elided-arg marker: a NON-DANGLING, ALWAYS-TRUE
# marker, used UNCONDITIONALLY (no per-arg pinned-vs-omitted guessing). It claims only
# what is universally true — the full content is recoverable by re-issuing the call or
# file_read'ing the path. A "the content is in the CURRENT WORKSPACE block" pointer is
# UNSAFE for an elided arg even when the call's target path is pinned: an elided arg is
# a write/edit ARG VALUE (an attempted or NEW body), NOT the file's current content, so
# the block does not carry it. (And a pinned file is already fully visible in the block,
# so the model needs no pointer to it anyway.) Kept angle-bracketed + "elided"/"full
# content" so the K1 execution guard (`_ELISION_MARKER_RE`) still detects a copy-back.
def _arg_snip_marker_neutral(n: int) -> str:
    # DE-TEMPTIFIED (elision redesign slice 1): the old wording told the model to
    # "re-issue the call" — which M3 took LITERALLY, copying this marker back into a new
    # tool call → K1 reject → re-issue → STUCK. The body is ALREADY applied; nothing to
    # re-issue. Render as inert metadata. KEEP the "<N chars … elided …>" grammar so the K1
    # guard (`_ELISION_MARKER_RE`) + `_ELISION_PARAPHRASE_RE` still detect a copy-back.
    return (
        f"<{n:,} chars elided — body already applied to the workspace; this is a history "
        "placeholder, NOT a tool argument: do not copy or re-send it. file_read the path "
        "if you need the content again>"
    )


def _snip_args(arguments: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in arguments.items():
        if isinstance(v, str) and len(v) > _ARG_SNIP_CHARS:
            # Always the assist-ON / pre-CW-3 directional marker. assist-OFF retargets
            # it (per pinned-in-full path) in ViewBuilder; assist-ON keeps it as-is.
            out[k] = _arg_snip_marker_below(len(v))
        else:
            out[k] = v
    return out


def retarget_elided_arg_markers(messages: list[LLMMessage]) -> list[LLMMessage]:
    """CW P1-a (round-2) — assist-OFF render pass: rewrite each elided tool-call
    ARGUMENT marker to the NEUTRAL, non-dangling marker.

    `_snip_args` emits the directional `_arg_snip_marker_below` unconditionally (it runs
    inside `View.of`, which has no tier context). For assist-OFF the CURRENT WORKSPACE
    block moved to the cacheable PREFIX, where the directional "below" is wrong AND a
    "the content is in the block" pointer is UNSAFE: an elided arg is a write/edit body
    (an attempted or NEW value), NOT the file's current content, so the block does not
    carry it even when the call's target path is pinned in full. So this pass rewrites
    EVERY elided arg to `_arg_snip_marker_neutral` — which claims only the always-true
    re-issue / file_read recovery — with NO per-arg pinned-vs-omitted guessing.

    assist-ON never calls this (the directional marker is correct + pre-CW-3 byte-
    identical for the tail-placed block). Pure: returns a new list; input unchanged.
    """
    out: list[LLMMessage] = []
    for msg in messages:
        if msg.role != "assistant" or not msg.tool_calls:
            out.append(msg)
            continue
        new_tcs: list[dict[str, Any]] = []
        mutated = False
        for tc in msg.tool_calls:
            if not isinstance(tc, dict):
                new_tcs.append(tc)
                continue
            args = tc.get("arguments")
            if not isinstance(args, dict):
                new_tcs.append(tc)
                continue
            new_args: dict[str, Any] | None = None
            for k, v in args.items():
                if not isinstance(v, str):
                    continue
                count = _ELISION_COUNT_RE.match(v)
                if count is None or _ELISION_MARKER_RE.search(v) is None:
                    continue  # not one of our markers — leave the model's arg alone
                n = int(count.group(1).replace(",", ""))
                replacement = _arg_snip_marker_neutral(n)
                if replacement == v:
                    continue
                if new_args is None:
                    new_args = dict(args)
                new_args[k] = replacement
            if new_args is not None:
                new_tc = dict(tc)
                new_tc["arguments"] = new_args
                new_tcs.append(new_tc)
                mutated = True
            else:
                new_tcs.append(tc)
        out.append(msg.model_copy(update={"tool_calls": new_tcs}) if mutated else msg)
    return out


def find_elided_arg_markers(arguments: dict[str, object]) -> list[str]:
    """K1 execution guard: return the argument keys whose string value carries an
    elision placeholder (the `_snip_args` marker copied back by a weak model).
    Empty list ⇒ the arguments are clean and safe to execute. Pure + deterministic.

    Matches BOTH the structural `<N chars … {elided|full content} …>` marker AND a
    model-PARAPHRASED placeholder that dropped the count anchor but kept the marker's
    signature tail prose (BW-02). Rejection-only — the retarget pass is unaffected."""
    return [
        k
        for k, v in arguments.items()
        if isinstance(v, str)
        and (
            _ELISION_MARKER_RE.search(v) is not None
            or _ELISION_PARAPHRASE_RE.search(v) is not None
        )
    ]


def value_is_only_elision_marker(value: object) -> bool:
    """True when `value` is a string consisting of NOTHING BUT an elision
    placeholder (plus surrounding whitespace) — i.e. the model copied the
    `_snip_args` marker back verbatim with no real content of its own around it.

    Used by the K1 recovery path: a PURE marker copy-back can be safely
    re-expanded to the original content the marker stood in for (the engine still
    holds it in the event log), because re-expansion can't clobber any real text
    the model authored — there is none. A marker EMBEDDED in real text (the model
    wrote a header, a marker, a footer) returns False so the recovery never
    silently drops the model's surrounding edits; that case falls through to the
    rejection-and-re-read path instead. Pure + deterministic."""
    if not isinstance(value, str):
        return False
    stripped = _ELISION_PARAPHRASE_RE.sub("", _ELISION_MARKER_RE.sub("", value))
    # Nothing matched ⇒ not a marker at all; or matched but real text remains.
    return value != stripped and stripped.strip() == ""


class ObservationEvent(BaseEvent, LLMConvertible):
    """The result of an ActionEvent's tool call (success path)."""

    kind: Literal[EventKind.OBSERVATION] = EventKind.OBSERVATION
    source: EventSource = EventSource.ENVIRONMENT
    tool_result: ToolResult
    # Correlates this observation to its action. NOT volatile for
    # reconstruction (needed to pair action/observation) but IS ignored by
    # stuck-equality (§6.3) since the action content is what matters.
    action_id: str

    def to_llm_message(self) -> LLMMessage:
        # A-S2 Snip: cap a single large observation before it hits the context.
        # CW-6: assist-OFF raises this cap (in tandem with the read budget) so a
        # large file_read observation is not snipped to a corrupted head/tail. The
        # override is set per-build by ViewBuilder from the derived caps; when unset
        # (assist-ON / no window) it is the byte-identical 8k calibration below.
        max_chars, head, tail = _OBS_SNIP_CHARS, _OBS_SNIP_HEAD, _OBS_SNIP_TAIL
        override = obs_snip_override.get()
        if override is not None and override > _OBS_SNIP_CHARS:
            # Scale head/tail to the raised cap using the same 5:2 ratio so a
            # genuinely-oversize output (beyond the raised cap) still degrades
            # gracefully; the cap itself is what spares an in-budget read.
            max_chars, head, tail = override, override * 5 // 8, override * 2 // 8
        return LLMMessage(
            role="tool",
            content=snip_content(
                self.tool_result.content,
                max_chars=max_chars,
                head=head,
                tail=tail,
            ),
            tool_call_id=self.tool_result.call_id,
        )


class AgentErrorEvent(BaseEvent, LLMConvertible):
    """An error observation — tool failed, action invalid, execution raised, or
    the human declined the proposed action. Distinct from ErrorEvent (which is
    conversation-fatal).

    `tool_call_id` carries the proposed action's call_id when the event is paired
    with an ActionEvent; this lets the provider adapter (OpenAI etc.) properly
    pair the assistant's tool_calls with their resulting messages. Required for
    refused / rejected actions where no real tool result exists."""

    kind: Literal[EventKind.AGENT_ERROR] = EventKind.AGENT_ERROR
    source: EventSource = EventSource.ENVIRONMENT
    error: str
    action_id: str | None = None  # the action that failed, if any
    tool_call_id: str | None = None  # for pairing with the assistant tool_call

    def to_llm_message(self) -> LLMMessage:
        # Pre-formatted content (e.g. wrapped in <system-reminder>...</…>) is
        # rendered as-is; raw error strings get the "ERROR:" prefix for the
        # model's parse. This lets the rejection path inject ambient reminders
        # without the user-tone framing of a tool-failure message.
        content = self.error if self.error.startswith("<") else f"ERROR: {self.error}"
        return LLMMessage(role="tool", content=content, tool_call_id=self.tool_call_id)


class CondensationEvent(BaseEvent):
    """A TOMBSTONE. Marks a span of prior events as forgotten and records the
    summary that replaces them. NOT LLMConvertible — the View applies it (§5).
    [CONTRACT: this is how forgetting is represented.]"""

    kind: Literal[EventKind.CONDENSATION] = EventKind.CONDENSATION
    source: EventSource = EventSource.SYSTEM
    # The seq range [start, end] (inclusive) this condensation forgets. The View
    # drops events whose seq falls in any active range.
    forgotten_start_seq: int
    forgotten_end_seq: int
    # The summary inserted in place of the span (inline, for atomicity).
    summary: str
    summary_role: Literal["system", "user"] = "user"
    reason: Literal["request", "tokens", "events", "hard_reset"] = "tokens"


class StatusEvent(BaseEvent):
    """A lifecycle/status transition. NOT LLMConvertible. Drives the UI and the
    loop's state machine reconstruction (§3)."""

    kind: Literal[EventKind.STATUS] = EventKind.STATUS
    source: EventSource = EventSource.SYSTEM
    status: ConversationStatus
    detail: str | None = None


class PlanEvent(BaseEvent, LLMConvertible):
    """A structured plan the agent proposed (in PLANNING mode) and the human is
    asked to approve before any work runs. LLMConvertible so the committed plan
    stays in the agent's context during execution — it renders as an assistant
    message restating the steps it agreed to carry out.

    `context` is an optional markdown body carrying the planner's findings from
    exploring the workspace + web (Claude-Code-style: explain WHY this plan, what
    you learned, the trade-offs). Empty by default for backward compatibility."""

    kind: Literal[EventKind.PLAN] = EventKind.PLAN
    source: EventSource = EventSource.AGENT
    summary: str  # one or two sentences: what this plan delivers
    steps: list[PlanStep]
    revision: int = 1  # bumps each time the user sends the plan back for changes
    context: str = ""  # optional markdown rationale + exploration findings

    def to_llm_message(self) -> LLMMessage:
        lines = [f"{i}. {s.title}" for i, s in enumerate(self.steps, start=1)]
        body = "\n".join(lines)
        # Include the context so the executing agent has its own findings in-View
        # — same role Claude Code's plan-file markdown plays during execution.
        ctx = f"\n\nContext:\n{self.context}" if self.context else ""
        return LLMMessage(
            role="assistant",
            content=f"Plan (revision {self.revision}): {self.summary}\n{body}{ctx}",
        )


class ReportEvent(BaseEvent, LLMConvertible):
    """A finished Deep Research report — the multi-section grounded synthesis
    produced from the per-run corpus. LLMConvertible so a follow-up turn in the
    same conversation has the committed report headers + summary in its View
    (the long body would blow the context window; we render headers only).

    `bounded_by` names the hard-cap that terminated the run, if any: "sources"
    (max_sources hit), "rounds" (max_rounds_per_subq hit on all sub-questions),
    "wall_clock" (max_wall_clock_s hit), or "subquestions" (decompose produced
    more than max_subquestions). None means the run completed naturally."""

    kind: Literal[EventKind.REPORT] = EventKind.REPORT
    source: EventSource = EventSource.AGENT
    query: str  # the original user question this report answers
    summary: str  # executive summary (one or two paragraphs, top-of-report)
    sections: list[ReportSection]
    # The cited subset (only passages actually referenced by some section). The UI
    # resolves [[passage_id]] markers against this list to render source cards.
    # Plain dict[str, Any] to keep `core` free of any `retrieval` import — the
    # producer (deep_research engine) populates with Passage.model_dump().
    passages: list[dict[str, Any]] = Field(default_factory=list)
    # The full discovery set (URL, title, snippet, status). All_hits for the
    # All-Searched / Cited tabs at report scale. Same plain-dict reason.
    all_hits: list[dict[str, Any]] = Field(default_factory=list)
    unsupported_count: int = 0  # whole-report total (sum across sections)
    bounded_by: str | None = None  # named cap if hit, else None (natural finish)
    # The depth tier the run used ("quick" / "standard_deep" / "exhaustive"),
    # surfaced for the UI's cost/time honesty + audit. Optional for backward-compat.
    depth_tier: str | None = None

    def to_llm_message(self) -> LLMMessage:
        # Render headers + summary only — the full body is too large for the View
        # and the citations would resolve to ids the model can't look up anyway.
        # This keeps the committed report present in-context for a follow-up turn
        # ("expand section 3") without bloating the window.
        headers = "\n".join(f"## {s.title}" for s in self.sections)
        bound = f"\n\n(Bounded by: {self.bounded_by}.)" if self.bounded_by else ""
        return LLMMessage(
            role="assistant",
            content=f"Research report for: {self.query}\n\n{self.summary}\n\n{headers}{bound}",
        )


class AlternativeOption(BaseModel):
    """One concrete next-step option the agent proposed after exhausting retries.
    Each option carries a human-readable description + a structured ToolCall the
    loop will execute as the next action if the user picks it."""

    model_config = ConfigDict(frozen=True, extra="forbid")
    id: str  # stable id for the user's pick_alternative frame
    title: str  # short label rendered on the option card (e.g. "Try with sudo")
    description: str  # one or two sentences: why this might work / what changes
    tool_name: str  # the tool the loop will call if this option is picked
    arguments: dict[str, Any] = Field(default_factory=dict)


class AlternativesEvent(BaseEvent, LLMConvertible):
    """The structured recovery hand-off. Emitted when the agent voluntarily calls
    `ask_user` WITH options — it enumerates 2–3 concrete next-step alternatives,
    those become this event, the loop halts at AWAITING_USER_DECISION, and the
    user picks one (or steers explicitly). The picked option's ToolCall becomes
    the next action. (The harness circuit breaker reaches the same status but with
    a free-form question, no clickable options.)

    Mirrors PlanEvent's shape (gate event + LLMConvertible so the proposed
    options stay in-context for any follow-up turn). `failed_action_id`
    correlates this gate with the action that triggered the recovery."""

    kind: Literal[EventKind.ALTERNATIVES] = EventKind.ALTERNATIVES
    source: EventSource = EventSource.AGENT
    failed_action_id: str  # the original ActionEvent.id that exhausted retries
    summary: str  # what we're choosing between, one sentence
    options: list[AlternativeOption]

    def to_llm_message(self) -> LLMMessage:
        lines = [
            f"{i}. {o.title} — {o.description}"
            for i, o in enumerate(self.options, start=1)
        ]
        body = "\n".join(lines)
        return LLMMessage(
            role="assistant",
            content=(
                f"After repeated failures on the prior step, I proposed these "
                f"alternatives: {self.summary}\n{body}"
            ),
        )


class KnowledgeEvent(BaseEvent, LLMConvertible):
    """A scoped best-practice snippet injected into the agent's context (Cluster
    7). `scope` is an optional applicability hint (a task keyword or path glob)
    the View can use to inject only relevant knowledge; `snippet` is the
    guidance. LLMConvertible so it renders into the model context, and pinned
    against condensation so standing guidance survives a long run."""

    kind: Literal[EventKind.KNOWLEDGE] = EventKind.KNOWLEDGE
    source: EventSource = EventSource.SYSTEM
    scope: str = ""
    snippet: str

    def to_llm_message(self) -> LLMMessage:
        scope = f" (applies to: {self.scope})" if self.scope else ""
        return LLMMessage(
            role="user",
            content=f"<knowledge{scope}>\n{self.snippet}\n</knowledge>",
        )


class DatasourceEvent(BaseEvent, LLMConvertible):
    """Durable data-API / schema documentation the agent learned or was given
    (Cluster 7). The long-horizon hazard this fixes: an API contract learned
    mid-run lives only in an Observation's inline text, which condensation later
    compresses into lossy prose → the agent hallucinates an endpoint. A
    DatasourceEvent is condensation-IMMUNE, so the exact contract stays verbatim
    across an arbitrarily long build."""

    kind: Literal[EventKind.DATASOURCE] = EventKind.DATASOURCE
    source: EventSource = EventSource.SYSTEM
    name: str  # the data source / API name
    docs: str  # endpoint shape, auth, params, example response — verbatim

    def to_llm_message(self) -> LLMMessage:
        return LLMMessage(
            role="user",
            content=f"<datasource name=\"{self.name}\">\n{self.docs}\n</datasource>",
        )


class DeliverableEvent(BaseEvent, LLMConvertible):
    """The agent's explicit 'here is the finished thing' handoff (Build). It names
    WHAT was produced and WHERE, so the UI can present a real handoff (open the
    live app / download the files) instead of leaving the user to guess what the
    run made. Distinct from the live preview (which shows work-in-progress): a
    DeliverableEvent is the agent affirming a result is ready.

    `kind`:
      • "app"   — a runnable result the user opens in the live preview (a built
                  site / running dev server rooted at `path`).
      • "files" — one or more workspace artifacts to download/inspect (`path` is
                  the file or directory).

    LLMConvertible so the agent's own context reflects what it has already handed
    off (it shouldn't re-deliver the same thing); the body stays terse."""

    kind: Literal[EventKind.DELIVERABLE] = EventKind.DELIVERABLE
    source: EventSource = EventSource.AGENT
    title: str  # short human label, e.g. "Landing page" / "Sales report"
    path: str  # workspace-relative path (dir for an app root, file/dir for files)
    artifact_kind: Literal["app", "files"] = "app"
    # Optional canonical URL the deliverable is reachable at (a deploy target, a
    # tunnel, or the live preview). When the agent serves to a known address it
    # passes it on `serve(url=…)`; the UI surfaces an "Open deployed app" link.
    deployment_url: str = ""

    def to_llm_message(self) -> LLMMessage:
        return LLMMessage(
            role="user",
            content=(
                f"<deliverable kind=\"{self.artifact_kind}\" path=\"{self.path}\">\n"
                f"{self.title}\n</deliverable>"
            ),
        )


class ErrorEvent(BaseEvent):
    """A conversation-level (fatal-ish) error, e.g. MaxIterationsReached.
    NOT LLMConvertible."""

    kind: Literal[EventKind.ERROR] = EventKind.ERROR
    source: EventSource = EventSource.SYSTEM
    code: str
    detail: str


class ScheduleEvent(BaseEvent):
    """A schedule was created or deleted for this conversation (RP-08).
    NOT LLMConvertible — it is a system lifecycle event."""

    kind: Literal[EventKind.SCHEDULE] = EventKind.SCHEDULE
    source: EventSource = EventSource.SYSTEM
    action: Literal["created", "deleted"]
    schedule_id: str
    rrule: str  # cron expression
    description: str


class ScheduleRunEvent(BaseEvent):
    """A scheduled run fired and was appended to this conversation (RP-08).
    NOT LLMConvertible — it is a system lifecycle event.

    `coalesced` is True when the server was down across N missed fires and this
    single run stands in for all of them (run-once-coalesced policy)."""

    kind: Literal[EventKind.SCHEDULE_RUN] = EventKind.SCHEDULE_RUN
    source: EventSource = EventSource.SYSTEM
    schedule_id: str
    coalesced: bool = False


class ClarifyQuestionItem(BaseModel):
    """One typed question in a ClarifyEvent. Each item has a stable id, the
    question text, a type that drives the UI input, and (after the user answers)
    the user's answer."""

    model_config = ConfigDict(frozen=True, extra="forbid")
    id: str  # stable id for this question within the clarify card
    question: str  # the question text (rendered as Markdown)
    type: Literal["short_text", "long_text", "choice"] = "short_text"
    # For choice-type questions: the allowed options.
    options: list[str] = Field(default_factory=list)
    # Populated by the user's response; empty until answered.
    answer: str = ""


class ClarifyEvent(BaseEvent):
    """Pre-plan clarification gate (RP-13). When the request is ambiguous and
    the planner needs structured user input before committing to a plan, it
    calls the `clarify` virtual tool. The loop intercepts the call, emits this
    event carrying MULTIPLE typed questions, and halts at
    AWAITING_USER_QUESTION. The user answers each question; the answers are
    re-injected as context and planning proceeds.

    NOT LLMConvertible — the clarify card is a UI gate, not a model-facing event.
    The user's answers are re-injected as a regular USER MessageEvent, which the
    model reads on its next View."""

    kind: Literal[EventKind.CLARIFY] = EventKind.CLARIFY
    source: EventSource = EventSource.AGENT
    question: str  # overarching question / summary of what needs clarification
    items: list[ClarifyQuestionItem]


class ContextResolvedEvent(BaseEvent):
    """CXT-3 — the agent's DEFERRED 'snip' mark: a seq range [start,end] the agent
    has declared resolved (an exploration concluded, stale tool chatter) and that
    MAY be forgotten from the model view later — but ONLY once a durable summary
    exists and context pressure warrants it (context_compact_if_needed). On its
    own this event changes nothing: it does not tombstone, so View.of is unaffected
    until a CondensationEvent is actually emitted for the range.

    NOT LLMConvertible — pure intent/bookkeeping. The model only ever sees the
    inline summary of the CondensationEvent that eventually executes the snip."""

    kind: Literal[EventKind.CONTEXT_RESOLVED] = EventKind.CONTEXT_RESOLVED
    source: EventSource = EventSource.AGENT
    range_id: str = Field(default_factory=lambda: f"cxr_{uuid.uuid4().hex}")
    forgotten_start_seq: int
    forgotten_end_seq: int
    reason: str = "resolved"
    # Set once a durable summary file has been written for this range (CXT-2 SUMMARY).
    summary_ref_path: str | None = None


class ContextSummaryEvent(BaseEvent):
    """CXT-3 — records that a durable summary was written for a resolved range
    (the 'state exists elsewhere' precondition for compaction). The non-empty
    `summary` is the content that will replace the forgotten span when the snip
    executes, so its presence + non-emptiness is the durability proof.

    NOT LLMConvertible — internal context-compaction marker."""

    kind: Literal[EventKind.CONTEXT_SUMMARY] = EventKind.CONTEXT_SUMMARY
    source: EventSource = EventSource.SYSTEM
    range_id: str
    rel_path: str
    summary: str
    artifact_kind: str = "summary"


# ---- the discriminated union the store/serde use ----------------------------

Event = Annotated[
    MessageEvent
    | ActionEvent
    | ObservationEvent
    | AgentErrorEvent
    | CondensationEvent
    | StatusEvent
    | PlanEvent
    | ReportEvent
    | AlternativesEvent
    | KnowledgeEvent
    | DatasourceEvent
    | DeliverableEvent
    | ErrorEvent
    | ScheduleEvent
    | ScheduleRunEvent
    | ClarifyEvent
    | ContextResolvedEvent
    | ContextSummaryEvent,
    Field(discriminator="kind"),
]

# Single shared validator/serializer for the union. Consumers parse arbitrary
# event dicts (post-migration) through this; the `kind` field selects the
# concrete type. (§4 serialization contract.)
EventAdapter: TypeAdapter[Event] = TypeAdapter(Event)


def event_to_json_dict(event: Event) -> dict[str, Any]:
    """Serialize one event to a JSON-safe dict (§4 rule 1): ISO datetimes,
    enums by value. The inverse is `event_from_json_dict`."""
    return event.model_dump(mode="json")


def event_from_json_dict(raw: dict[str, Any]) -> Event:
    """Deserialize a (already-migrated) JSON dict back into the concrete event
    type via the discriminated union. Callers should run `migrate_event` first
    (see migration.py) so old persisted events stay readable forever."""
    return EventAdapter.validate_python(raw)
