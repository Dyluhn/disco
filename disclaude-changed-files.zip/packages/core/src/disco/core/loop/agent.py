"""RouterAgent — the concrete `Agent` (agent-loop-contract.md §3).

The brain: given the model-facing View and the available tools, it builds a
CompletionRequest(role=AGENT_DRIVER), calls the LLMRouter, and maps the
response's FIRST ProposedToolCall to a ToolCall — the only place the model is
consulted for action selection. It returns exactly one AgentStep (one-action-
per-iteration). It does NOT execute tools.

Typed against `DefaultLLMRouter` (not the bare `LLMRouter` protocol) because it
uses that router's `CallContext` extension to thread the conversation id, the
(now-advisory) runtime signals, and the per-conversation `model_override` — the
backend hook for the main-screen model pill (router contract §4, v1.2).

v1.2 note: under the deterministic router these `overflow_signal` fields
(difficulty, tool-error streak, confidence) no longer steer model selection; they
are carried as advisory metadata only. The seam is unchanged — the agent still
asks for the AGENT_DRIVER role and gets back the assigned model — so the loop did
NOT need to change. The one addition is `model_override`, which lets the operator
pin the driver model for THIS conversation from the UI.

v1 finish convention [INTERIOR]: if the model returns no tool call, the agent is
treated as finished (it stopped acting). A dedicated `finish` tool is the likely
refinement once the Tool/Sandbox contract lands; the loop already supports a
thought-only no-op step independently of this Agent's choice.

v1 risk [INTERIOR]: the response carries no structured self-risk, so
`self_assessed_risk` stays UNKNOWN — the independent SecurityAnalyzer is the real
signal (BoD §17.2).
"""

from __future__ import annotations

import re
import uuid

from ..env import disco_env
from ..events import ToolCall
from ..llm import (
    CallContext,
    CapabilityProfile,
    CompletionRequest,
    DefaultLLMRouter,
    ModelRole,
    OperatingMode,
    OverflowSignal,
    Requirement,
)
from ..obs import log_span
from ..view import View
from .boundaries import AgentStep, StreamHook, is_finish_tool_name

# The View feeds the model's own prior thoughts back into context with a rotating
# surface-form prefix ("Reasoning: …" / "Thought: …" — a deterministic-by-seq
# anti-overfit decoration, see view.py B3). A model (observed: MiniMax) then ECHOES
# that decoration into the NEXT thought it emits, and since each turn re-decorates,
# the prefix STACKS — the stored/displayed thought becomes
# "Reasoning: Reasoning: Reasoning: …". We strip the leaked leading decorator(s) off
# the model's response text BEFORE it is stored as the ActionEvent thought, which
# both cleans the stored event AND breaks the feedback loop (the clean thought goes
# back into context, gets exactly one fresh decoration, never compounds).
#
# Scoped to ONLY the surface forms the View applies to AGENT thoughts (Reasoning /
# Thought) — the "Observation:" / "Output:" forms decorate tool-result messages, not
# thoughts, so a thought never legitimately starts with one and we don't strip them.
_THOUGHT_DECOR_RE = re.compile(
    r"^(?:\s*(?:Reasoning|Thought)\s*:\s*)+",
    re.IGNORECASE,
)


def _clean_thought(text: str) -> str:
    """Strip leaked, stacked surface-form prefixes the View added and the model
    echoed back ("Reasoning: Reasoning: …"). Only LEADING repeated decorators are
    removed — a thought that legitimately says "Reasoning: foo" mid-sentence is
    untouched. Idempotent; a clean thought is returned unchanged."""
    return _THOUGHT_DECOR_RE.sub("", text)


def _has_unclosed_think(text: str) -> bool:
    """A tool-less turn whose visible content opens a ``<think>`` block but never
    closes it was CUT OFF mid-reasoning — the model ran out of output budget
    before it finished thinking (and therefore before it could emit a tool call).

    This is the MiniMax wedge (fix-slides-wedge): a reasoning model that inlines
    its chain-of-thought as literal ``<think>`` tags in ``content`` (rather than a
    separate ``reasoning_content`` field) can exhaust the provider's output cap
    deep inside the block, yet NOT report ``finish_reason=="length"`` — so the
    plain length check below misses it and the turn is mis-read as a clean,
    completed no-op. An unclosed ``<think>`` is an unambiguous, model-agnostic
    "the turn never finished" signal: openai_provider already documents the same
    invariant for its F5 think-budget pass. Models that stream reasoning out of
    band (no ``<think>`` in ``content``) never match, so this is naturally scoped
    to the inline-think providers that actually hit the wedge."""
    if "<think>" not in text:
        return False
    return text.lower().count("<think>") > text.lower().count("</think>")


def _pick_tool_call(tool_calls, finish_alias):  # noqa: ANN001 — duck-typed provider calls
    """P6/W-32 — pick the single action from a (possibly batched) response. Prefer the
    first NON-finish call so a batched [finish/finalizer, real action] still executes the
    real work (the finish/finalizer must then come on its own turn, where the gates run).
    The contract finalizer alias counts as finish — so it can't shadow a real action — and
    the chosen name is CANONICALIZED to "finish" when it is the finish signal, so the alias
    name never reaches the engine/event log; every downstream surface sees plain "finish".
    Returns (tool_name, arguments)."""
    pc = next(
        (c for c in tool_calls if not is_finish_tool_name(c.tool_name, finish_alias)),
        tool_calls[0],
    )
    name = "finish" if is_finish_tool_name(pc.tool_name, finish_alias) else pc.tool_name
    return name, pc.arguments


class RouterAgent:
    """[CONTRACT] An `Agent` that wraps the LLM router."""

    def __init__(
        self,
        router: DefaultLLMRouter,
        *,
        conversation_id: str | None = None,
        requirements: frozenset[Requirement] = frozenset({Requirement.TOOL_CALLING}),
        model_override: str | None = None,
        temperature: float = 0.4,
        prose_finishes: bool = True,
    ) -> None:
        self._router = router
        self._cid = conversation_id
        self._requirements = requirements
        # Cluster 9 anti-fewshot jitter for the acting driver (0.0 would be a
        # deterministic self-imitation chain on a long run).
        self._temperature = temperature
        # Research↔Build isolation: completion semantics are owned by the AGENT,
        # not a mode flag. `prose_finishes=True` means a tool-less prose turn IS
        # the answer (Research/chat). `False` means talking isn't finishing —
        # the run ends only via the `finish` tool (Build). See ResearchAgent /
        # BuildAgent below; this base default (True) matches the original v1
        # convention so direct RouterAgent(router) callers are unchanged.
        self._prose_finishes = prose_finishes
        # P6 — the active Build contract's verification finalizer (ready_for_*_verification),
        # treated identically to `finish` in batched-call selection so the model can't
        # discard a real action by batching it with the finalizer, and so the canonical
        # "finish" name flows to every downstream surface. None ⇒ no contract governs.
        # Set post-construction by the runtime (set_finish_alias) once the contract resolves.
        self._finish_alias: str | None = None
        # v1.2 model-pill hook: the driver model key chosen for THIS conversation,
        # overriding the settings assignment. None → follow settings. Set by the
        # app/agent server from the per-conversation pill selection.
        self._model_override = model_override

    def set_finish_alias(self, alias: str | None) -> None:
        """P6 — bind the active Build contract's verification finalizer (or None). Set by
        the runtime once the contract resolves, so the agent treats that name as `finish`."""
        self._finish_alias = alias

    async def step(
        self,
        view: View,
        tools: list,
        *,
        mode: OperatingMode,
        overflow_signal: OverflowSignal,
        on_stream: StreamHook | None = None,
        temperature: float | None = None,
        assist: bool = False,
        attempt: int = 1,
        provider_prefs: dict | None = None,
    ) -> AgentStep:
        # B9: Assistant prefill. In PLANNING mode, force
        # the model to start its thought with an honest acknowledgment of
        # the task, reducing the "lazy prose" failure. Gated by flag.
        prefill = None
        if mode == OperatingMode.PLANNING and disco_env("PLAN_PREFILL") == "1":
            prefill = (
                "I've analyzed the request and current workspace state. "
                "To advance, I will now"
            )
        # C13: Mirror the B9 prefill pattern for the EXECUTION phase
        # (LONG_HORIZON mode in the engine: `execution_mode: OperatingMode =
        # OperatingMode.LONG_HORIZON`). Biases the model toward a concrete
        # next-action tool call rather than another "let me think..."
        # prose turn. Gated by an independent flag so it can be A/B'd
        # against the planning flag; default OFF keeps the gated-experiment
        # contract — flag OFF is byte-identical to today (prefill stays None).
        elif mode == OperatingMode.LONG_HORIZON and disco_env("EXEC_PREFILL") == "1":
            prefill = (
                "Given the current workspace state and the last tool result, "
                "my next action is to"
            )

        req = CompletionRequest(
            profile=CapabilityProfile(
                role=ModelRole.AGENT_DRIVER,
                difficulty=overflow_signal.difficulty,
                requirements=self._requirements,
                mode=mode,
            ),
            messages=view.messages,
            tools=tools,
            assistant_prefill=prefill,
            assist=assist,  # weak-model assist gate → F1 reads req.assist for recovery
            # Cluster 9: a small non-zero temperature for the driver (anti-fewshot).
            # A long uniform run at temp 0.0 is a near-deterministic self-imitation
            # chain — maximally prone to repeating a prior failing pattern. The
            # summarizer + other structured roles stay at 0.0 (they set it
            # explicitly); only the acting driver gets the jitter. A per-step
            # `temperature` override (the loop's stuck-escape bump) wins when given.
            temperature=temperature if temperature is not None else self._temperature,
            request_id=f"req_{uuid.uuid4().hex}",
            # F5 — repair-attempt counter. The engine increments this on each
            # retry of a failed call; the provider reads it to disable thinking
            # on attempt ≥ 2. Default 1 = first try; assist-OFF callers ignore.
            attempt=attempt,
            # P2 — provider routing escalation (threaded from the driver on
            # LLMProviderUnavailable retries; None on first/normal calls).
            provider_prefs=provider_prefs,
        )
        ctx = CallContext(
            conversation_id=self._cid,
            consecutive_tool_errors=overflow_signal.consecutive_tool_errors,
            last_local_confidence=overflow_signal.last_local_confidence,
            model_override=self._model_override,
        )
        # STREAM the driver call, not `complete()`. This is load-bearing, not an
        # optimization: for large tool-call arguments (e.g. a `file_write` with a big
        # file body), some OpenAI-compatible providers (observed: DeepSeek via
        # OpenRouter/NovitaAI) return EMPTY `arguments` in non-streaming mode but
        # assemble them correctly from streamed deltas — and far faster (~18s vs ~5min
        # for the same request). Consuming the stream to its final chunk gives the
        # correctly-assembled response; surfacing the intermediate deltas to the UI
        # (watch-it-write) is the next layer on top of this.
        resp = None
        with log_span("agent.step", role="agent_driver", cid=self._cid) as span:
            async for chunk in self._router.stream_complete(req, context=ctx):
                # Forward tool-call arg deltas (the file body) to the watch-it-write
                # hook. The agent stays ignorant of tool semantics — it just relays the
                # raw fragments; the loop accumulates + extracts the field to display.
                if on_stream is not None and chunk.tool_args_delta:
                    await on_stream(chunk)
                if chunk.done and chunk.final is not None:
                    resp = chunk.final
            if resp is None:
                # The stream produced no terminal chunk — fall back to the non-stream
                # call so a provider that doesn't stream still works (never wedge).
                resp = await self._router.complete(req, context=ctx)
            # measured fields land on the span's `end` record (trace-assertable)
            span["model"] = resp.model_used
            span["in_tokens"] = resp.usage.input_tokens
            span["out_tokens"] = resp.usage.output_tokens
            span["cached_tokens"] = resp.usage.cached_tokens
            span["finish"] = str(resp.finish_reason)

        if resp.tool_calls:
            # One-action-per-iteration: take the FIRST proposed call (§3).
            # W-32 (secondary): when the model BATCHES a `finish` ALONGSIDE a real
            # action in the same response, a bare tool_calls[0] could let the
            # finish preempt the real work. Prefer the first NON-finish call so a
            # batched [finish, real_action] still executes the work; the
            # affirmative finish must then come on its own turn (where the finish
            # gates run). All-finish / single-finish falls back to the first call.
            _name, _args = _pick_tool_call(resp.tool_calls, self._finish_alias)
            return AgentStep(
                thought=_clean_thought(resp.text),
                tool_call=ToolCall(tool_name=_name, arguments=_args),
                finished=False,
                llm_response_id=resp.request_id,
            )
        # No tool call → a tool-less PROSE turn. Completion semantics are owned
        # by the AGENT (Research↔Build isolation), not derived from the per-step
        # mode:
        #   - ResearchAgent (prose_finishes=True): the prose IS the answer →
        #     finished. Research/chat completion depends on this.
        #   - BuildAgent (prose_finishes=False): talking is NOT finishing. The
        #     run ends only via the affirmative `finish` tool the loop intercepts,
        #     so mid-run talk-back can't silently end a build.
        #
        # W-31 — TRUNCATION GUARD. `finish_reason=="length"` means the provider
        # cut the message off mid-sentence (the output budget was exhausted —
        # worst right after a re-steer, when a long <think> preamble eats it).
        # A truncated prose turn is NOT a completed turn: surfacing it as
        # finished (Research) — or as a clean no-op (Build) — is the bug. Flag it
        # and force `finished=False` so the loop injects a "continue where you
        # left off" reminder and re-steps instead of ending on a fragment.
        #
        # fix-slides-wedge — STRUCTURAL truncation backstop. Some reasoning
        # providers (MiniMax inlines its chain-of-thought as `<think>` tags in
        # `content`) exhaust the output cap mid-reasoning WITHOUT reporting
        # `finish_reason=="length"`, so the check above misses it and the
        # never-finished, tool-less turn is mis-classified as a clean no-op. The
        # loop then silently re-steps a 2-minute reasoning dump that never reaches
        # a tool call — a wedge to the user (the agent slides build that drafted a
        # whole deck inside one unclosed `<think>` and produced nothing). An
        # unclosed `<think>` is an unambiguous "cut off mid-thought" signal:
        # treat it as truncated too, so the W-31 handler fires its "you were cut
        # off — be concise and take the action now with a tool call" steer
        # immediately (turn 1, not after 3 silent no-ops) and the no-op valve
        # still bounds a truncation storm into a VISIBLE PAUSED halt.
        truncated = resp.finish_reason == "length" or _has_unclosed_think(resp.text)
        return AgentStep(
            thought=_clean_thought(resp.text),
            tool_call=None,
            finished=self._prose_finishes and not truncated,
            truncated=truncated,
            llm_response_id=resp.request_id,
        )


class ResearchAgent(RouterAgent):
    """The Research / plain-chat brain. A tool-less prose turn IS the answer →
    the run finishes (single-pass-ish grounded chat). Deterministic by default
    (temperature 0.0) — research answers shouldn't jitter. This is a distinct
    class from BuildAgent so a Build-surface change can never silently alter
    Research's completion behavior (the leak that caused the GAP B bug)."""

    def __init__(
        self,
        router: DefaultLLMRouter,
        *,
        conversation_id: str | None = None,
        requirements: frozenset[Requirement] = frozenset({Requirement.TOOL_CALLING}),
        model_override: str | None = None,
        temperature: float = 0.0,
    ) -> None:
        super().__init__(
            router,
            conversation_id=conversation_id,
            requirements=requirements,
            model_override=model_override,
            temperature=temperature,
            prose_finishes=True,
        )


class BuildAgent(RouterAgent):
    """The Build (agentic) brain. Talking is NOT finishing — the long-horizon
    run ends only via the affirmative `finish` tool, so the mid-run talk-back
    the prompt encourages can't silently end a build. A small non-zero
    temperature (anti-fewshot) keeps a long uniform run from collapsing into a
    deterministic self-imitation chain."""

    def __init__(
        self,
        router: DefaultLLMRouter,
        *,
        conversation_id: str | None = None,
        requirements: frozenset[Requirement] = frozenset({Requirement.TOOL_CALLING}),
        model_override: str | None = None,
        temperature: float = 0.4,
    ) -> None:
        super().__init__(
            router,
            conversation_id=conversation_id,
            requirements=requirements,
            model_override=model_override,
            temperature=temperature,
            prose_finishes=False,
        )
